//
//  main.cpp
//  HW1
//
//  Created by Samantha Pope on 1/16/24.
//

#include <iostream>
#include "cmdline.hpp"

int main(int argc, const char * argv[]) {
    useArgs(argc,argv);
    return 0;
}
