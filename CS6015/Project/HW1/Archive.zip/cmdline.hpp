//
//  cmdline.hpp
//  HW1
//
//  Created by Samantha Pope on 1/16/24.
//

#ifndef cmdline_hpp
#define cmdline_hpp

#include <stdio.h>
void useArgs(int argc, const char* argv[]);

#endif /* cmdline_hpp */
